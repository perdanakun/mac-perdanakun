export const clamp = (value, min, max) => Math.min(Math.max(value, min), Math.max(min, max));

export function desktopBounds() {
  const menu = document.querySelector('[data-menu-bar]')?.getBoundingClientRect();
  const dock = document.querySelector('[data-dock]')?.getBoundingClientRect();
  return {
    left: 12,
    top: (menu?.bottom ?? 28) + 12,
    right: window.innerWidth - 12,
    bottom: Math.max((menu?.bottom ?? 28) + 100, (dock?.top ?? window.innerHeight - 90) - 16),
  };
}

export function fitFrame(frame) {
  const bounds = desktopBounds();
  const width = Math.min(frame.width, bounds.right - bounds.left);
  const height = Math.min(frame.height, bounds.bottom - bounds.top);
  return {
    width, height,
    x: clamp(frame.x, bounds.left, bounds.right - width),
    y: clamp(frame.y, bounds.top, bounds.bottom - height),
  };
}

export function initialFrame(kind, index) {
  const bounds = desktopBounds();
  const width = Math.min(kind === 'mail' ? 520 : kind === 'notes' ? 860 : kind === 'gallery' ? 980 : 900, bounds.right - bounds.left);
  const height = Math.min(kind === 'mail' ? 440 : kind === 'gallery' ? 680 : 650, bounds.bottom - bounds.top);
  const offset = (index % 4) * 22;
  return fitFrame({
    x: (window.innerWidth - width) / 2 + offset,
    y: bounds.top + 12 + offset,
    width, height,
  });
}

export function rectOf(element) {
  if (!element?.isConnected) return null;
  const { left: x, top: y, width, height } = element.getBoundingClientRect();
  return { x, y, width, height };
}

// Keep artwork proportional while the window travels to its originating icon.
export function collapseTransform(source, frame) {
  if (!source) return { x: 0, y: 12, scale: .96, opacity: 0 };
  const scale = Math.max(.02, Math.min(source.width / frame.width, source.height / frame.height, 1));
  return {
    x: source.x + (source.width - frame.width * scale) / 2 - frame.x,
    y: source.y + (source.height - frame.height * scale) / 2 - frame.y,
    scale,
    opacity: 0,
  };
}
