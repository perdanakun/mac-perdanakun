import { useRef, useState } from 'react';
import { motion, useAnimationControls, useMotionValue, useReducedMotion, useSpring, useTransform } from 'framer-motion';
import { profile } from '../data/profile.js';

function DockItem({ app, mouseX, mobile, open, onOpen }) {
  const ref = useRef(null);
  const reduced = useReducedMotion();
  const bounce = useAnimationControls();
  const [failedIcon, setFailedIcon] = useState(null);
  const customIcon = Boolean(app.icon && failedIcon !== app.icon);
  const icon = customIcon ? app.icon : app.fallbackIcon;
  const requestedScale = mobile ? app.iconScaleMobile ?? app.iconScale : app.iconScale;
  // Optical sizing belongs to the artwork, not the hover animation or hit target.
  const iconScale = customIcon && Number.isFinite(requestedScale) && requestedScale > 0 ? requestedScale : 1;
  const targetScale = useTransform(mouseX, value => {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect || !Number.isFinite(value)) return 1;
    const distance = Math.abs(value - rect.left - rect.width / 2);
    // A cosine falloff has no abrupt corner as adjacent icons enter the hover range.
    return distance >= 120 ? 1 : 1 + .45 * (1 + Math.cos(Math.PI * distance / 120)) / 2;
  });
  const scale = useSpring(targetScale, { stiffness: 460, damping: 30, mass: .45 });
  return (
    <li className="dock-item" data-divider={app.dividerBefore || undefined}>
      <button ref={ref} type="button" className="dock-button" aria-label={app.label} aria-haspopup="dialog"
        onClick={event => {
          if (!reduced) void bounce.start({ y: [0, mobile ? -8 : -14, 0], transition: { duration: .38, ease: ['easeOut', 'easeIn'] } });
          onOpen(app, event.currentTarget);
        }}>
        <motion.span className="dock-icon-scale" style={{ scale: mobile || reduced ? 1 : scale }}>
          <span className="dock-icon-art" style={{ '--dock-art-scale': iconScale }}>
            <motion.img src={icon} alt="" width={64} height={64} draggable="false" animate={bounce}
              onError={() => setFailedIcon(app.icon)} />
          </span>
        </motion.span>
        <span className="dock-label" aria-hidden="true">{app.label}</span>
        <span className="dock-dot" data-open={open} aria-hidden="true" />
      </button>
    </li>
  );
}

export default function Dock({ apps, mobile, openIds, onOpen }) {
  const mouseX = useMotionValue(Infinity);
  return (
    <nav className="dock" data-dock aria-label={profile.ui.dock}
      onPointerMove={event => { if (!mobile && event.pointerType === 'mouse') mouseX.set(event.clientX); }}
      onPointerLeave={() => mouseX.set(Infinity)}>
      <ul>{apps.map(app => <DockItem key={app.id} app={app} mouseX={mouseX} mobile={mobile}
        open={openIds.has(app.id)} onOpen={onOpen} />)}</ul>
    </nav>
  );
}
